

export const environment = {
  production: false,
  url: 'http://localhost:4000/api/v1/series'
};

