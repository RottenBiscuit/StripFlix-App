export interface APIResponseSeries {
  status: string
  data: Serie[]
}

export interface Serie {
  _id: string
  title: string
  emision_date: string
  images: string[]
  categories: string[]
  sinopsis: string
  chapters: number
}
