import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./pages/home/home.page').then((m) => m.HomePage),
  },{
    path: 'components/header',
    loadComponent: () => import('./components/header/header.component').then((m) => m.HeaderComponent),
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'tabs',
    loadComponent: () => import('./components/tabs/tabs.page').then(m => m.TabsPage)
  },
  {
    path: 'categories-page',
    loadComponent: () => import('./pages/categories-page/categories-page.page').then( m => m.CategoriesPagePage)
  },
  {
    path: 'search-page',
    loadComponent: () => import('./pages/search-page/search-page.page').then( m => m.SearchPagePage)
  },
  {
    path: 'details-page/:id',
    loadComponent: () => import('./pages/details-page/details-page.page').then( m => m.DetailsPagePage)
  },
];
