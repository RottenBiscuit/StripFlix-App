import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CategoriesPagePage } from './categories-page.page';

describe('CategoriesPagePage', () => {
  let component: CategoriesPagePage;
  let fixture: ComponentFixture<CategoriesPagePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoriesPagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
