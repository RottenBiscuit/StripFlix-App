import {Component, CUSTOM_ELEMENTS_SCHEMA, inject, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonButton,
  IonButtons,
  IonCard,
  IonCardContent,
  IonCardHeader, IonCol,
  IonContent, IonGrid, IonList, IonRow,

} from '@ionic/angular/standalone';
import {SerieService} from "../../services/serie.service";
import {Serie} from "../../common/interface";
import {HeaderComponent} from "../../components/header/header.component";
import {RouterLink} from "@angular/router";
import {register} from "swiper/element/bundle";
register()
@Component({
  selector: 'app-categories-page',
  templateUrl: './categories-page.page.html',
  styleUrls: ['./categories-page.page.scss'],
  standalone: true,
  imports: [IonContent, CommonModule, FormsModule, HeaderComponent, IonCard, IonCardContent, IonCardHeader, IonCol, IonGrid, IonList, IonRow, RouterLink, IonButton, IonButtons],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CategoriesPagePage implements OnInit {
  private serieService: SerieService = inject(SerieService);
  categories: String[] = [];
  series: Serie[] = [];

  constructor() { }

  ngOnInit() {
    this.loadSeries()
    this.loadCategories()


  }
  private loadCategories() {
    this.categories = [];
    this.serieService.getCategories().subscribe({
      next: (data) => {
        console.log("Respuesta de la API:", data);

        this.categories = data;
      },
      error: (err: Error) => console.error("Error al cargar las categorias:", err),
      complete: () => console.log('Categorias cargadas correctamente')
    });
  }

  private loadSeries() {
    this.serieService.getSeries().subscribe({
      next: (data) => {
        console.log("Respuesta de la API:", data);

        this.series = data;
      },
      error: (err: Error) => console.error("Error al cargar series:", err),
      complete: () => console.log('Series cargadas correctamente')
    });
  }
}
