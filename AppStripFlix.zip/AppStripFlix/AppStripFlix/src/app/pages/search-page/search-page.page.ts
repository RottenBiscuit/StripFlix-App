import {Component, CUSTOM_ELEMENTS_SCHEMA, inject, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonCard, IonCardContent, IonCardHeader, IonCol,
  IonContent, IonGrid,
 IonList, IonRow,
  IonSearchbar,

} from '@ionic/angular/standalone';
import {SerieService} from "../../services/serie.service";
import {Serie} from "../../common/interface";
import {FiltroPipe} from "../../pipes/filtro.pipe";
import {HeaderComponent} from "../../components/header/header.component";
import {RouterLink} from "@angular/router";
import {register} from "swiper/element/bundle";
register()
@Component({
  selector: 'app-search-page',
  templateUrl: './search-page.page.html',
  styleUrls: ['./search-page.page.scss'],
  standalone: true,
  imports: [IonContent,CommonModule, FormsModule, IonSearchbar, FiltroPipe, IonList, HeaderComponent, IonCard, IonCardContent, IonCardHeader, IonCol, IonGrid, IonRow, RouterLink],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SearchPagePage implements OnInit {
  private serieService: SerieService = inject(SerieService);
  series: Serie[] = [];
  textoBuscar = '';
  constructor() { }

  ngOnInit() {
    this.loadSeries()
  }
  private loadSeries() {
    this.serieService.getSeries().subscribe({
      next: (data) => {
        console.log("Respuesta de la API:", data);

        this.series = data;
      },
      error: (err: Error) => console.error("Error al cargar series:", err),
      complete: () => console.log('Series cargadas correctamente')
    });
  }
  buscar(event: any) {
    this.textoBuscar = event.detail.value;
  }
}
