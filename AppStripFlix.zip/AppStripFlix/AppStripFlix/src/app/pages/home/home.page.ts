import {Component, CUSTOM_ELEMENTS_SCHEMA, inject, OnInit} from '@angular/core';
import {
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardContent,
  IonList,
  IonGrid,
  IonRow,
  IonCol
} from '@ionic/angular/standalone';
import { HeaderComponent } from "../../components/header/header.component";
import { SerieService } from "../../services/serie.service";
import { Serie } from "../../common/interface";
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonContent, HeaderComponent, IonCard, IonCardHeader, IonCardContent, IonList, IonGrid, IonRow, IonCol, RouterLink],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class HomePage implements OnInit{
  private serieService: SerieService = inject(SerieService);
  series: Serie[] = [];

  constructor() {}

  ngOnInit() {
    this.loadSeries();
  }

  private loadSeries() {
    this.serieService.getSeries().subscribe({
      next: (data) => {
        console.log("Respuesta de la API:", data);

        this.series = data.sort((a, b) => {
          return new Date(b.emision_date).getTime() - new Date(a.emision_date).getTime();
        });
      },
      error: (err: Error) => console.error("Error al cargar series:", err),
      complete: () => console.log('Series cargadas correctamente')
    });
  }
}
