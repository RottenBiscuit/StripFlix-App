import {Component, CUSTOM_ELEMENTS_SCHEMA, OnInit} from '@angular/core';
import {CommonModule, DatePipe} from '@angular/common';
import { FormsModule } from '@angular/forms';
import {IonCard, IonCardTitle, IonChip, IonContent} from '@ionic/angular/standalone';
import {Serie} from "../../common/interface";
import {SerieService} from "../../services/serie.service";
import {ActivatedRoute} from "@angular/router";
import {register} from "swiper/element/bundle";
import {HeaderComponent} from "../../components/header/header.component";
register()

@Component({
  selector: 'app-details-page',
  templateUrl: './details-page.page.html',
  styleUrls: ['./details-page.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonCardTitle, IonCard, IonContent, HeaderComponent, IonChip,],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],

})
export class DetailsPagePage implements OnInit {
  serie: Serie = { _id: '', title: '', emision_date:'', images: [], categories: [], sinopsis: '', chapters: 0 };

  constructor( private serieService: SerieService,
               private route: ActivatedRoute,) {

  }

  ngOnInit() {
    this.loadSerie()
  }
  loadSerie() {
    const id = this.route.snapshot.paramMap.get('id');
    console.log('ID de la serie:', id);
    if (id) {
      this.serieService.getSeries().subscribe((series: Serie[]) => {
        const serieEncontrada = series.find((serie: Serie) => serie._id === id);
        if (serieEncontrada) {
          this.serie = serieEncontrada;
          console.log('Serie cargada:', this.serie);
        } else {
          console.error('Serie no encontrada');
        }
      });
    }
  }

}
