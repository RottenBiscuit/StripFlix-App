import {inject, Injectable} from '@angular/core';
import {map, Observable} from "rxjs";
import {APIResponseSeries, Serie} from "../common/interface";
import {environment} from "../../environments/environment";
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class SerieService {
  private http: HttpClient = inject(HttpClient);

  getSeries(): Observable<Serie[]>{
    return this.http.get<APIResponseSeries>(environment.url).pipe(
      map((response) => response.data)
    );  }
  getCategories(): Observable<String[]>{
    return this.http.get<String[]>(environment.url + '/categories')
  }
  getSerie(id: string): Observable<Serie[]>{
    return this.http.get<Serie[]>(environment.url + '/' + id)
  }
}
