import { Component } from '@angular/core';
import {IonApp, IonRouterOutlet,} from '@ionic/angular/standalone';
import {register} from "swiper/element/bundle";
import {MenuComponent} from "./components/menu/menu.component";
import {TabsPage} from "./components/tabs/tabs.page";
import {HeaderComponent} from "./components/header/header.component";
import {infinite} from "ionicons/icons";
import {addIcons} from "ionicons";
register()
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  imports: [IonApp, IonRouterOutlet, MenuComponent, TabsPage, HeaderComponent],
})
export class AppComponent {
  constructor() {
    addIcons({infinite});
  }

}
