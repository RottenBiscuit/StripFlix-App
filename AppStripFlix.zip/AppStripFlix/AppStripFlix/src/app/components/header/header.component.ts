import {Component, inject, OnInit} from '@angular/core';
import {
  IonAvatar,
  IonBackButton, IonButton,
  IonButtons,
  IonHeader,
   IonImg, IonMenuToggle,
  IonToolbar
} from "@ionic/angular/standalone";
import {RouterLink} from "@angular/router";


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  imports: [
    IonToolbar,
    IonAvatar,
    RouterLink,
    IonHeader,
    IonBackButton,
    IonButtons,
    IonMenuToggle,
    IonButton,
    IonImg,

  ]
})
export class HeaderComponent  implements OnInit {
 ngOnInit() {
 }

}
