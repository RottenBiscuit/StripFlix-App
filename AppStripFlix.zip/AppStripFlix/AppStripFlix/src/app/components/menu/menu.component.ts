import {Component, inject, OnInit} from '@angular/core';
import {

  IonButtons,
  IonContent,
  IonHeader,
  IonMenu, IonMenuButton,
  IonTitle,
  IonToolbar
} from "@ionic/angular/standalone";
import {SerieService} from "../../services/serie.service";

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss'],
  standalone: true,
  imports: [
    IonMenu,
    IonContent,
    IonTitle,
    IonToolbar,
    IonHeader,
    IonButtons,
    IonMenuButton,

  ]
})
export class MenuComponent  implements OnInit {
  private serieService: SerieService = inject(SerieService);
  categories: String[] = [];


  ngOnInit(){
    this.loadCategories();
  }

  private loadCategories() {
    this.serieService.getCategories().subscribe({
      next: (data) => {
        console.log("Respuesta de la API:", data);
        this.categories = [];

      },
      error: (err: Error) => console.error("Error al cargar categorias:", err),
      complete: () => console.log('Categorias cargadas correctamente')
    });
  }
}
