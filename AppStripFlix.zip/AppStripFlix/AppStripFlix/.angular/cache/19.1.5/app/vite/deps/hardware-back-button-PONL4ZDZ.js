import {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
} from "./chunk-HDD6I4HK.js";
import "./chunk-IDWKFNXT.js";
import "./chunk-BBHNRBDL.js";
import "./chunk-ACUVEYEP.js";
import "./chunk-ZVATTXSA.js";
export {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
};
